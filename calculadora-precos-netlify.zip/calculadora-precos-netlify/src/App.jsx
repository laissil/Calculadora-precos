
import React, { useState, useEffect } from 'react'

const defaultTaxas = [
  { nome: 'iFood', valor: 12 },
  { nome: 'Maquininha', valor: 4 },
]

function App() {
  const [precoProduto, setPrecoProduto] = useState(0)
  const [taxas, setTaxas] = useState(() => {
    const taxasSalvas = localStorage.getItem('taxas')
    return taxasSalvas ? JSON.parse(taxasSalvas) : defaultTaxas
  })
  const [novaTaxa, setNovaTaxa] = useState({ nome: '', valor: '' })

  useEffect(() => {
    localStorage.setItem('taxas', JSON.stringify(taxas))
  }, [taxas])

  const precoFinal = taxas.reduce(
    (acc, taxa) => acc * (1 - taxa.valor / 100),
    precoProduto
  )

  const adicionarTaxa = () => {
    if (!novaTaxa.nome || !novaTaxa.valor) return
    setTaxas([...taxas, { nome: novaTaxa.nome, valor: parseFloat(novaTaxa.valor) }])
    setNovaTaxa({ nome: '', valor: '' })
  }

  const removerTaxa = (index) => {
    const novasTaxas = taxas.filter((_, i) => i !== index)
    setTaxas(novasTaxas)
  }

  return (
    <div className="max-w-xl mx-auto p-4 space-y-6 font-sans">
      <h1 className="text-2xl font-bold">Calculadora de Preços</h1>
      <div className="space-y-4 p-4 border rounded-xl shadow-sm">
        <div>
          <label className="block mb-1 font-semibold">Preço do Produto</label>
          <input
            type="number"
            className="w-full p-2 border rounded"
            value={precoProduto}
            onChange={(e) => setPrecoProduto(parseFloat(e.target.value))}
            placeholder="Ex: 100"
          />
        </div>

        <div>
          <h2 className="font-semibold mb-2">Taxas Aplicadas</h2>
          <ul className="space-y-1">
            {taxas.map((taxa, index) => (
              <li key={index} className="flex justify-between items-center">
                <span>{taxa.nome}: {taxa.valor}%</span>
                <button
                  className="text-red-500 text-sm hover:underline"
                  onClick={() => removerTaxa(index)}
                >
                  Remover
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <input
            className="p-2 border rounded"
            placeholder="Nome da Taxa"
            value={novaTaxa.nome}
            onChange={(e) => setNovaTaxa({ ...novaTaxa, nome: e.target.value })}
          />
          <input
            className="p-2 border rounded"
            type="number"
            placeholder="Valor %"
            value={novaTaxa.valor}
            onChange={(e) => setNovaTaxa({ ...novaTaxa, valor: e.target.value })}
          />
          <button
            className="col-span-2 bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
            onClick={adicionarTaxa}
          >
            Adicionar Taxa
          </button>
        </div>

        <div>
          <h2 className="font-semibold">Resultado</h2>
          <p>Preço após taxas: R$ {precoFinal.toFixed(2)}</p>
        </div>
      </div>
    </div>
  )
}

export default App
